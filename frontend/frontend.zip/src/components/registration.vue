<template>
  <div class="mainstyle dsaxz">
    <div class="mainstyle sdacaae">
      <div class="mainstyle scaweed">
        <div class="mainstyle sadcae">
          <div class="mainstyle dasdae"></div>
          <div class="mainstyle sdawcada">
            <div class="mainstyle styrtdacsd">
              <div class="mainstyle xcsseq">
                <div class="mainstyle sazjfg">
                  <svg class="svgg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                       width="216.103"
                       height="58.809" viewBox="0 0 216.103 58.809">
                    <defs>
                      <clipPath id="clip-path">
                        <path id="Контур_45" data-name="Контур 45"
                              d="M6.81,9.01V7.854L.06,7.63V9.084A29.274,29.274,0,0,0,8.674,29.856l4.848-4.811A22.076,22.076,0,0,1,6.81,9.01Z"
                              transform="translate(-0.06 -7.63)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-2">
                        <rect id="Прямоугольник_3" data-name="Прямоугольник 3" width="384" height="64"
                              transform="translate(0)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-3">
                        <path id="Контур_46" data-name="Контур 46"
                              d="M23.131,7.049a6.414,6.414,0,0,1,1.193,0L24.66.225,23.392.15A29.5,29.5,0,0,0,2.36,8.8l4.848,4.811A22.375,22.375,0,0,1,23.131,7.049Z"
                              transform="translate(-2.36 -0.15)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-5">
                        <path id="Контур_47" data-name="Контур 47"
                              d="M9.022,18.975a6.228,6.228,0,0,1-1.156,0L7.53,25.762H8.984A29.5,29.5,0,0,0,29.83,17.111L24.982,12.3A22.039,22.039,0,0,1,9.022,18.975Z"
                              transform="translate(-7.53 -12.3)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-7">
                        <path id="Контур_48" data-name="Контур 48"
                              d="M20.8,10.805l5.743-4.1A29.535,29.535,0,0,0,7.9.14V7.076a22.71,22.71,0,0,1,12.9,3.729Z"
                              transform="translate(-7.9 -0.14)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-9">
                        <path id="Контур_50" data-name="Контур 50"
                              d="M23.9,19.548A22.375,22.375,0,0,1,7.152,12.09L2.08,16.64a29.385,29.385,0,0,0,21.815,9.7Z"
                              transform="translate(-2.08 -12.09)" fill="none"/>
                      </clipPath>
                      <clipPath id="clip-path-11">
                        <path id="Контур_51" data-name="Контур 51"
                              d="M14.3,7.224,9.708,2.19A29.2,29.2,0,0,0,.05,23.856H6.837A22.375,22.375,0,0,1,14.3,7.224Z"
                              transform="translate(-0.05 -2.19)" fill="none"/>
                      </clipPath>
                    </defs>
                    <g id="Layer_" data-name="Layer " transform="translate(-0.227 -0.522)">
                      <g id="Сгруппировать_44" data-name="Сгруппировать 44" transform="translate(0.04)">
                        <path id="Контур_39" data-name="Контур 39"
                              d="M59.845,9.172,67.862,3.28H41.05V38.669H67.862V32.74H48.732V23.716H65.066V17.824H48.732V9.172Z"
                              transform="translate(111.881 8.951)" fill="#21a038"/>
                        <path id="Контур_40" data-name="Контур 40"
                              d="M46.811,32.74H38.794V22.97h8.018c4.885,0,7.123,1.6,7.123,4.922S51.51,32.74,46.811,32.74Zm1.268-15.588H38.794V9.172H53.71l7.98-5.892H31V38.669H46.961c8.913,0,14.1-4.065,14.1-11.187S56.544,17.152,48.079,17.152Z"
                              transform="translate(84.603 8.951)" fill="#21a038"/>
                        <path id="Контур_41" data-name="Контур 41"
                              d="M64.644,22.746h-6.9V9.172h6.9c4.96,0,7.458,2.461,7.458,6.787S69.491,22.746,64.644,22.746Zm0-19.466H50.1V38.669h7.645V28.638h6.9c9.286,0,14.916-4.848,14.916-12.679S74.078,3.28,64.644,3.28Z"
                              transform="translate(136.729 8.951)" fill="#21a038"/>
                        <path id="Контур_42" data-name="Контур 42"
                              d="M46.358,31.387a13.984,13.984,0,0,1-6.6,1.678,11.411,11.411,0,0,1-11.9-11.821,11.411,11.411,0,0,1,11.9-11.709,12.008,12.008,0,0,1,6.973,2.2L52.25,7.819l-.373-.373A18.2,18.2,0,0,0,39.533,3.157,19.69,19.69,0,0,0,25.959,8.191a17.266,17.266,0,0,0-5.333,13.052,18.2,18.2,0,0,0,5.333,13.164,19.28,19.28,0,0,0,13.5,5.183,18.235,18.235,0,0,0,13.574-5.37L48.11,30.492Z"
                              transform="translate(56.268 8.59)" fill="#21a038"/>
                        <path id="Контур_44" data-name="Контур 44"
                              d="M39.271,3.22A34.121,34.121,0,0,1,43,9.037L16.187,28.8,5,21.754V13.289L16.187,20.3Z"
                              transform="translate(13.646 8.788)" fill="#21a038"/>
                      </g>
                      <g id="Сгруппировать_27" data-name="Сгруппировать 27" transform="translate(0.264 28.453)"
                         clip-path="url(#clip-path)">
                        <g id="Сгруппировать_26" data-name="Сгруппировать 26" transform="translate(-0.224 -28.453)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_25" data-name="Сгруппировать 25" transform="translate(-0.149)">
                            <image id="Прямоугольник_2" data-name="Прямоугольник 2" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAAHa0lEQVR4Xu3cXXKrRhBA4R6Mk4esKBvLhrKeLCnmPojpn5keQJZ1DfL5qlKSYFDip1M9iJR///t7EZxaKSJFFpnKIpMsUoro+6ksds4fK6Lvb9fUtRLWlrLIJLK+2pr2uP9cv6O49fVzvVb0mLjj6/v1FQDu9edf/8i8twjfQ+ORxCaL1ShmacBkkan4KEkasSOxErldK2GNWLBcrGQNGAA8gnCdSI1VDcYwVEnMQmx2YpVGSK+NAdJ1NUI1ROt6u7aPlehaAPg6hOsEtiejvclpGU5bk/vu0px7NFZxulpsoiJWAJ6McH2TcWz2YmSTk611kZO6xdjESix+pcT3YXtQYuwsWBYrkbo92GwHbvy9APBVCNdv5KemGJs6+RyLVTeNSd023IpVe71fG2PXxsqmrBgpfmQB4DsQrieLk43FRqOShao5309jt/D4aIUtQP96V6xcpIgVgJMiXE/g7ymlk1EIUHI+jZWb1qSPVbflp9cmsZIapo1Yub+DWAE4E8L1RbJYpT+o6MIl6fl+GjseK789GKYtYgXgBRCuB2g8hrFZdIKyMOUxy6exNkqjWFmA2rjVz/W/VfRYHiuetQJwdoTrTj5WGpsQkTZWeczSaUxuYesnp/tipcfFPRisU1ScqIgVgKshXAdoDIaxsX/yyWkcMB+rdGKq/55w3q2rEaohWtdvxUp0LQBcD+HaMNzac7HanZzSWIleW5pzPlbFr5VjsfJxCxMVsQLwIghXY3syWg5NTt25NUA1hCFWYvHzU51uB/qgudhZsNxEKHV70CJVjwPAqyBcImFqChNVjUrxn+P5Iw8GxxjZcZuc/PUxVj52bYxsyvJBs0kMAF7Rjw1XGxOLzS0U6VTVxCydxtoJqfvcHCdWAHCXHxUuf09pasLRH/MxE/feB2yN3EasNEz+mho//RzXbcbK/R3ECsBP9PLhymOV/KDi4Pn+HtfRWPnPfbSIFQAc85Lh0ngMY7PoBJWd97HSaUujth+hPkrjbcOyrpX2mMRY8awVANy8TLh8rDQ2ISIWq637WOm0ta4v/lofpyRq+SS2rpX9B4OlRmv8JwPAj3TpcNVYjWPjY5XfxxpOY+v64cRU/z3hvFtXI6QBct9FrADg0y4ZrnFsXKh2Jqc0ciJ6bWm+28dqtD24FSsft7D9R6wA4C6XCdderLbPW1y6aUxqyJpYiQ9Ue71fG2NnwXITody+x09U9TgA4D6nDpefmjRExUUlfHZB2omVj40/b1NRdn2MlY9dGyObsnzQbBIDAHze6cLVxqSNTRqqJmbpNNZOSN3n5vgjsQrHiRUAfKVThMvfU8piY8cGMashawK2Fav2/lTx14ZXW7cfqzhlAQC+3reFq41VnWam7tg4ZvV83dr7XKwsSt3P3JtYiX4nsQKA7/Jbw6Xx8NNNiM2i09TW+RqW/pyPUh+hPkr5tqGIXSviYxUjpb8M7P9UAMCTPD1cPlY1DLtbfyEydW0ybblYpRFqQjdap9Of8GAwAJzd08K1HZsYlHyqGkxj7rtLe424KStEysWqRkgDtFjQkljxrBUAnMuXhmscGxeqnckpjZyIXhtiJRbHUuL7sD0oMXYWLNFzIhYuYgUA5/VwuHysYmwWjcU4Zu29p/Xc4Vi11/u127HyU5a4SPEjCwA4t0+Fy28BaoiKi0oIV4xZPd9OY3FLT8K1w+NJrHzsLEbNqwaMWAHA1RwOV9yG62OTTl0aqDxWMYBxjUaoO25hujtW4TixAoAr2gyX/wFEFhsN1Shmzfl+23Acq3YL0W8PhmmrHIlVnLIAANfVhauN1fAe1YGY5dPY0VhZgPz1Pnb1WtFjxAoAXt0sIhYPDcp2rEYxawPmv6+fnPZj5eM2Ffvln4Q1YsFyseLBYAB4TfPb9KFTUBoqP/WEyKyv2bTlYpVGSK+NAdJ1NUI1ROt6u7aPlehaAMArm/8oHy42+eTkzw+3DkX0fGnOPRqrOF0tNlERKwD4ceb36f8uRtnkZOHy6+oWYxMrsfiVEt9/9sFgnaiIFQD8aPP79NFMTjFW3TQmddtwK1bJvSux633s2ljZlBUjxY8sAAAi68Sl0ekCFmNlr4Pjd8XKRYpYAQAOmt+njy5W/h5XFqsapno8bCsm60pdp++bWIXjxAoAMDa/l/4e11as2i1Evz3Y3sfaj1WcsgAA2HObuNIojWJlAcq3DS1SoseIFQDga8zz9DGcmI7GSqT+8m89pmGKkdKfsQ/+YwAA2DPP5cMiVEMVInXsWatRrETXAgDwuPl9fQA5/uDiWKx83MJERawAAE8yz9k9Ltl+MNhPWX6iqscBAHiWsFV42yb0sbIYhV8EhlitW4IAAPwGtx9nECsAwEXMc/kYx0rcvS1iBQA4gfmtLMQKAHAZ85tOXBYrnrUCAJzV/FZ41goAcB1z/T9fAABwBdPeAgAAzoRwAQAuhXABAC6FcAEALoVwAQAuhXABAC6FcAEALoVwAQAuhXABAC6FcAEALoVwAQAuhXABAC6FcAEALoVwAQAuhXABAC7lF98p0fNK2w7mAAAAAElFTkSuQmCC"/>
                          </g>
                        </g>
                      </g>
                      <g id="Сгруппировать_30" data-name="Сгруппировать 30" transform="translate(8.841 0.559)"
                         clip-path="url(#clip-path-3)">
                        <g id="Сгруппировать_29" data-name="Сгруппировать 29" transform="translate(-8.801 -0.559)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_28" data-name="Сгруппировать 28" transform="translate(-0.149)">
                            <image id="Прямоугольник_4" data-name="Прямоугольник 4" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAAF5klEQVR4Xu3dSZKjSBCF4ReZu97Ucep4dZ0+Vp9E9CIIwh13UmhAUPB/ZjKRKIflMx+CLL/+/W/QKkW325eG4UvD8D1d1/fv8fp7/FzSMKgMN2kYpOE2vsw9rfyzAACM/vz+R1/3vqkbVEp9tev6LnN9Uw+kMr7MdWmv+NsBAFjjgeCSWijNw6sFWL8nqUhDUQ+qYtOK5AIAPOeh4MorrnZ9m4XXvOKq70O4BwDAeg8FV+XbhL3iskHW7pvwspUX7UIAwJMeDq684vKfTaFWpKEFVTbzIr0AAA96OLjsHOvn1mG2NVjDaqg/TG4BAB72RHBJyxuGyZJGm2tNrUJpKtFILgDAg54KLj/bkupihm0T+nahD6p6zZIGAOAZTwVXrLiyey3IkvlWsa/0DwAAkHoyuOTmXL41mMy7ivyZrrCkAQDAOk8H1zyglqowX3XJvff1DcILALDOC8ElLYdWXNZw4cWZLgDAk14KrnybUIpBprFdOAZVWNKgZQgAWOel4PJLGD6o4pJGk8y3qLoAACu9GFxSDKr2hHhffVVl9uDd8Xr8DACAe14OrqW1+KwK621CySTX2C5s9wAAWPZycFUtoPwT4mO7kCUNAMBr3hJcrRWYL2vM7pV8ScNfAwCQe0tw9dlWD68YWrbimjNnugrhBQBY9qbgkpaCqi9m9Cpsqq5si9BVYQAA5N4WXH621a9jkKm3C+tPqoUVSxoAgHveFlxLCxn5qnwzCy+WNAAAd7wxuKQWStk2YTjTVZIzXROSCwCQe2tw5RVXu/ar8j6tyvSiXQgA+Mlbg6uazbPSDcN234QXZ7oAACu8Pbjyist/FpY0Fs90kV4AAO/twWXnWD+3Du2SRtPaheZLAACMDYJLWt4wtEsa7XvHuZZd0uBMFwBgwSbB5WdbUtwwNMsaLajqT6qFFUsaAIDMJsG1XHHFGVicZ7Xqy1RhAACMNgquFlBZUCXzriJ/pissaQAAUG0WXPOAilVY/R5fdcm99/UNwgsAUG0YXNJyaMVlDRdenOkCACzYNLh8UEnzZQ1XfRVxpgsAcNemwbWmTdhnX40PrEGi6gIATDYOLiluE940bxP2iix58K5blQcAXN3mwZVVWvmGoZRvFPLgXQBAt3lwVS2g/BPi46q8FOZbUwVGuxAA8KHgaq3AbJsw3CtmSaOXYfKBBgC4qo8El51j5W1CW3Vl4cSZLgBA9aHgkmqbMNswjKvyrroKZ7oILgC4so8Fl59ttWt77/6ZLpY0AAAfC6680rrJr8r/fKarV10CAFzUB4NLaqEUg6pVX62dKKkkZ7omJBcAXNVHgytbgQ9twukzm1a9ZUi7EACu7aPBVcWgqtfxiRouvMKSRva7AQBn9/Hgyisu/9m9JQ1bgQEAruXjwWVX4O+1DqPWLjRfAgAuZYfgkuJixrz66lXYNNeySxrhqRoAgKvYJbjyM13zILuZDuG8RSiWNADgonYJrrhN2OdacVU+mW8V+8r/AgDgnHYKrhZQWVDFQKtLGjJBFSswAMA17BZcWUD5Ksx+z6ziGt/7+gbhBQBXsWNwScuhFZc1XHhxpgsALmvX4PJBJc0rLVd9FXGmCwCwb3DZ0MrahH72NVfDaqg/TG4BwEXsHFzSmjZhr8iK+e/I6u3C8TMAwPntHlx+BV6y/3DSB5mUbxTy4F0AuJLdgysNqIUqrJrNt1rVRbsQAC7hAMHVKi4pe0J8aB0Ws6TRyzD5QAMAnNUhgmu+pJFVYf1+Fk6c6QKAqzhIcEl2tpW3CVsVJrnqKpzpIrgA4MwOE1x+ttWu7T0TZLZdaEKMJQ0AOL/DBFesrga1J8TnSxpSmG+xpAEAp3eg4JLm86zYJmztREml+AfvurAiuQDgrA4VXNlsK4ZXu2fTqrcMaRcCwLkdKrgqv03YZ1w381m978IrLGnE3wwA+PsdLriyiquU+Fk407VQgQEAzuVwwWWrqqXWYVzSsMyZLnILAE7ngMEl5RuGtvrqVdg017ItQleFAQDO5H+Nv9qCUcB9jgAAAABJRU5ErkJggg=="/>
                          </g>
                        </g>
                      </g>
                      <g id="Сгруппировать_33" data-name="Сгруппировать 33" transform="translate(28.12 45.868)"
                         clip-path="url(#clip-path-5)">
                        <g id="Сгруппировать_32" data-name="Сгруппировать 32" transform="translate(-28.08 -45.868)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_31" data-name="Сгруппировать 31" transform="translate(-0.149)">
                            <image id="Прямоугольник_6" data-name="Прямоугольник 6" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAAFrUlEQVR4Xu3cQXLjNhSE4X46Uba5T/Y5VM6T+8RJPJOFBbDxAMpTqSFIE/9XxSFFwSOv2NUA5Pjjz1+/6yf797v09i799U36+3l+e5fe/Fyvv4/f+yb98y799F8OAPBl/f7Lb3p8Nuj/iPg4HtrOj3SOKNfRj5UUKv8AALA5Jrj0DKX4uC5BFvb6Yfcfo3tBbgEAeocEV2lMW6uytmXNKwdcM/b5GgAAd0hwSf2UYMgCay+8yqFtDAAA7rBsGK1nlVAqjawLr3K2nwtaFwDAHBZcMQok2fRh07xiWwuT3X/x/wMA1nRYNuTQ8kBqmteLgGO6EACQHZYLtUFZMHlA+caNLtDSGAAAisOCS7K2NWhTZZ0r0r29dgYAgHRwcDVtaxBQ9X5I9YvI1sTqOhfJBQB4OjS4vGX1QdWuc/m9sLE0LgCAOzS4SjCN1reG04fWtHxnIetcAIDi0OCS+rWr3MC69a1IY2PCLwkA+DIOz4S9jRd+3sZEE1ohG0frAgBoQnB1IeWNq5xT88rTiCXEAAA4PrjUh1Wz27C8tuu9MQAATAkuX7f6kTWv3LRY5wIAFFPyoE7/RXvdrHH5ffUNjOlCAIA0K7hSYJWgyjsJP8bE1r5sbEgkFwBgTnB5cwoPpUGIebvyseXnAQBrm5IFTbtSG0x5M0befdhMJ9K4AGB5U4JL6teqRpsyfmQMAGBt07LAp/tGGzC8VfkXkeuYck3rAoClTQuu0qDyVOBnzat57/mzAIB1TQ2uGliDYPJG1axtlbO2MQCAdU0NrqZReVjZe92Uoo1lnQsAMDUHvGXlbfGlVTXvadzSKF0AsK6pwTVsV7JWZW0rIpq25Zs0SC4AWNfc4NJ4DatZ7xrd83NM/qUBAJcyNQNCNhWorU11zcvG5E0abIkHgLVNDS5pa0yj8GrWtF6MeRBcALCs6cGVt7yPAmrbnBH9GG1jAADrmR9cUrOTcG/Nay/gfDoRALCe6cHljenVJowccM3mjedrAMB6pgeX1Laq4QYNqQ+vctgYAMB6Tnn+e7sKC6Zmg4YGbcvHBOtcALCiU4Irr2flEKtBJukR0X4B2cINALCec4JLbWg1gVRCza/3Am73EwAAd3XKs782KAsmD6hm2jAHWhoDAFjLKcElWdvaa15qQ+tVOwMArOO04GralgWTb8LYmtf2B3frmOdBcgHAWk4LrldBFWrXuer0oGyKsRwvPgMAcD+nBVcJpldBNVrzagLveQ0AWMdpwSWlKcIcTB5a6huZTzECANZx6nN/FExl+q+ugdUx0YaWvRe0LgBYxqnB1YWUN7ByTs1rb6chAGAN5waX+rBqdhuW13adw6vcBwCs4fTganYSphY1al57ZwDAGk5/5tcGtdOmHhoH3CjoAAD3d35weVCl8PKdhB/3Y2tf5d7zILkAYA2nB1duTl1YqZ8a9AZWx7/4DADAfZz+vPdgCu03sLBzt5HjeQ0AuL/Tg0vq16pGmzJ+ZAwA4P4u8bz36b7RBgxvVf5F5DqmXNO6AOD2LhFcpUHlqcDPmtdo7QsAcG+XCa4aWBZQNdDK6/TeaAwA4N4uE1y+i/DVelbegZjHAADu7TLP+uGUoAeT2vuhdoqR6UIAWMNlgqtZ38rtK/JUYbShZkFGcgHAvV0nuNSuXXmA1bP6e93U4f5HAABu4DLP+VAfTE2binSdzjX4aFwAcGuXCS5p3KLC76cx/trPAID7ulRw5S3voxCr04hqv4hcN2+I1gUAd3at4JKaTRd5KrBpW6lp1XvPsQCAe7pUcHljGk0BdtOHKdDqQXIBwG1dKriktkENN2hIfXiVw8YAAO7pcs/4PP1XgqnZoKFB2/IxwToXANzV5YJrb7dgDa8SZJIeEf33v8QaFwDc2fWCS6k5yQKphJpf7wXc7icAAL6yyz3fa4OyQMph1lyX8YMxAID7+Q82VzZlilgKNwAAAABJRU5ErkJggg=="/>
                          </g>
                        </g>
                      </g>
                      <g id="Сгруппировать_36" data-name="Сгруппировать 36" transform="translate(29.5 0.522)"
                         clip-path="url(#clip-path-7)">
                        <g id="Сгруппировать_35" data-name="Сгруппировать 35" transform="translate(-29.46 -0.522)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_34" data-name="Сгруппировать 34" transform="translate(-0.149)">
                            <image id="Прямоугольник_8" data-name="Прямоугольник 8" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAADhUlEQVR4Xu3cW3KbMAAFUDnL6Fa6s+6i68waavXDYAQWNg9JMOGcGSYxxvm9w8W5t6+/3zGcxC3EEOI93MK/7ud9dO4W7yGEe7h17z2v6c4D8LP9+f0rfH26qK3YHSHcnqdiF15hfD5055PPAPDznSi44hBS3ZH9PfY/3/0tAH6q0wRXeif1DKf03EygSTCAazlNcK2tCZ/XxhCEF8B1nCe4Yh9My2rC9FoAruMUwTWq/j7mkJoQ4MpOEVzZ51dxGlD9+wM1IcD1nCO4sjVh/39dk0AL0y9nAHAlhwfXfE3Yh1f6sg8yAK7q8ODK1oQzx+ifj1++Mg/AFZwguDKimhCAvIOD6xFO+WCa1oRBVgFwbHBtXctQEwJc16HBlVZ+S9Yy1IQAHBhc72pCo7oA5B0WXFtrQgkGcG2HBdfamvB5bQxBeAFc13HBFY3qArDeIcH1flR3ekJNCMDgkODKPr8aPedK3x+oCQE4JriyNaG1DAA+ax5cRnUB2KN5cGVrwpnDqC4AUwcEV0ZUEwKwTOPgeoSTUV0AtmoaXFvXMtSEAPSaBlda+S1Zy1ATAjDVMLje1YRGdQFYpllwba0JJRgAqWbBtbYmfF4bQxBeAPTaBVc0qgvAfk2C6/Oo7nxtCACpJsGVBlF+VHe4xqguAO+0Ca5sTWgtA4D1qgeXUV0ASqoeXNmacOYwqgvAJw2CKyOqCQHYpnJwPcJp2ajutEoEgFdVgyu/lhGHcy81Yfe7mhCAGVWDKw2q9O7KqC4AW1UMrnc1oVFdALapFlxGdQGooVpw5WtCo7oA7FMvuKJRXQDKqxJcy0Z1+7sxNSEAy1UJrjSI0rur20swjV+rCQH4pE5wZWvC7rW1DAB2KB5cRnUBqKl4cM3VhOPnWP37w2esZQCwRIXgSr/mnp5TEwKwX+Hger27ej+qK6wAWKdocM2P6qoJASijaHClld94VPd5ehxYakIAVioYXI+7LKO6ANRULLiM6gLQQrHgyteERnUBKKtccEWjugDUVyS4lo/qqgkB2KdIcGWDKTuqO6YmBGCtMsGVrQm719YyAChod3AZ1QWgpd3BNVcTjp9j9e8Pn7GWAcAW+4MrJndVCaO6ANSwM7hyd1VDKKkJAShtV3AZ1QWgtV3BlVZ+RnUBaGFHcD3usozqAtDS5uAyqgvAETYHV74mNKoLQF3bgysa1QWgvf/QxGF6LrewJAAAAABJRU5ErkJggg=="/>
                          </g>
                        </g>
                      </g>
                      <g id="Сгруппировать_45" data-name="Сгруппировать 45" transform="translate(0.04)">
                        <path id="Контур_49" data-name="Контур 49"
                              d="M26.32,11.848a30.654,30.654,0,0,0-.485-5.258L19.458,11.4v.447A22.375,22.375,0,0,1,12,28.592l4.587,5.034A29.236,29.236,0,0,0,26.32,11.848Z"
                              transform="translate(32.75 17.985)" fill="#21a038"/>
                      </g>
                      <g id="Сгруппировать_40" data-name="Сгруппировать 40" transform="translate(7.797 45.085)"
                         clip-path="url(#clip-path-9)">
                        <g id="Сгруппировать_39" data-name="Сгруппировать 39" transform="translate(-7.757 -45.085)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_38" data-name="Сгруппировать 38" transform="translate(-0.149)">
                            <image id="Прямоугольник_11" data-name="Прямоугольник 11" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAAGGElEQVR4Xu3dTY7rNhCF0Sv3EjLKJrKprD7TDJ+fVRmIRRZp2fq17FjfAYx2yw0EGV1Ukdev+/efP0wfpLdOvTr1JvW66NZ3utlFv+2im6X3/UXX/qKrv7eLfvc/utpFv24/uvY/+tVfdO1/9FH/cwCATf76829dpv7oSJZew/tOZsPP3j+z4VmvIdxMHnLhp3W6mX8OAPg2nxVc1kkpcIZXN4RV+BkDqrfw3MK0lv4GAPB9Piq4pDJZKYVSn373CSwHljyoyrM8bRnBBQDf6mOCy6pJS0MgxedpRWghrEp4dertUgUYAOA7fU5wWQyvsB6MK8AqvOqVYa9Ot3DeBQD4Th8RXNUlihRWZm2IpYsaKZg8vPIzi589+A8BAP73PiK45OEkNa90nuU3CcOZV3u2xZoQAM7hI4JrmKbCutDSRBWnriqc0hlXXBl6yLEmBICv9vbg8ulqeB9Wgv5ZnLh8NdiEVa/Q3WJNCABf7f3BZWPdrTB5xaDyKcyf2/26EADw3d4eXFKZrPLFjBxaet7dai9mEFwA8PXeGlxj3a12TdhexijhVcLK14QAgO/33uCyGF7lanu5mBGuvY9OWJehuyWmLQA4i7cFV3WHwleE1oZYvAYfQmxkRcilDAA4h7cF17Pu1hBidLcAAPfeFlyPulv5OwlTgJVworsFAHhTcPl0NbwvNwmHL9atA4zuFgAgektwSVPdrbIm9KmL7hYAQHpTcJU14aPuVgimcM5V/U5wAcApHR5cfiFjeD/V3QoTWJ64hhfdLQA4p+ODy6SyJixhNK+7JdHdAoBzOzy4pDJZTXe3ynpw+Kz+V465lAEA53NocHk4lUsZzeWMJrTobgEAWscGl7Vh5a9H3a3yN3S3AADSgcFVbfV8TZimL7pbAIC5Dguu+BVPfpMwT1pWAszPrvKFDT/3shRarAkB4NQOC66qu+VnWiG0lnS3jOACgNM6JLjuulu2rrvlIcaWEADO65jgMqntbpWLGeX3Z90tP/tiTQgA53ZIcEn33a3yjRnhUkazHozdLT/f4lIGAJzby4OL7hYAYE+vDy5rw8pfClNVuEUYVohj1+EBAOf20uCqtnq+JoxnXeFZ1d9qworuFgDAvTS4nnW3hhuD992t8l2FdLcAAPdeGlxzulu5v6UYWmHiCutDAABeFlxzu1v5BqGVNSHdLQDAI68LLpPmdrfihGW+LvRnYk0IACheFlxSmaymulvDRJYmMHWiuwUAeOQlwbW0u1X9HHkBAOBeE1zWhFVeE9LdAgBss3twVVu9sCYsE1eXbxc+626VSxsP/kMAgFPaPbhid6tMXAo3Bp91t7p8tuXnWwAARLsHV+xulTOtElr5NmGerOhuAQDm2zW42u5WWQmWMItX3eluAQCW2je4TBrtbsWffrYVJiy6WwCAuXYNLimsCX1F6L8rnmmls670+Xh3i+ACANzbLbjGulv5i3UlulsAgF3sF1ymEFphPRhXgCm86G4BANbaJbiqSxRhTViHWLkST3cLALDWLsE12d0Ka8LqdqGHldHdAgDMs0twLepuhdCq1oRhfQgAwCObg8unrPzeV4L59zBdtWHVhBbdLQDAlO3BZelfN1ZYE+bJy1eITThZlwMtB5lYEwIApm0OLqlMVvJAUr02zGtAtd2tcr7FmhAAMMem4BrrbU11t3J4WScvHfsLAIAp24LL6huEc7pbcWXYW6dbOO8CAGDK6uCqLlFYuUlYh5jK+VY46xrrcNHdAgDMsTq49uhusSYEACy1OrhKd8tvEno4hamrCie6WwCA7VYFl09Zw/uwEvTP4sTVhlUIrVteIQIAMM+64LLp7lY1Vflzn7w8wMSaEACwzKrgkspktbW7RXABAJZYHFxzu1seZlV4WSe6WwCALZYHl8XwCuvBuAJ8dBEjvae7BQBYa1FwVZcorNwkrEMsXdSwcrbVpxVidTkj/S0AAEssCq4l3S0/82rPtlgTAgC2WBRcq7pbNrIyTM8AAFhqdnD5lDW8DytB/yxOXGkyo7sFANjb/OCyhd0tC8/jxQ2xJgQArDc7uKQyWfnFjFndrZE1IcEFAFjrP3XLQVDtQPvrAAAAAElFTkSuQmCC"/>
                          </g>
                        </g>
                      </g>
                      <g id="Сгруппировать_43" data-name="Сгруппировать 43" transform="translate(0.227 8.167)"
                         clip-path="url(#clip-path-11)">
                        <g id="Сгруппировать_42" data-name="Сгруппировать 42" transform="translate(-0.187 -8.167)"
                           clip-path="url(#clip-path-2)">
                          <g id="Сгруппировать_41" data-name="Сгруппировать 41" transform="translate(-0.149)">
                            <image id="Прямоугольник_13" data-name="Прямоугольник 13" width="384.845" height="63.544"
                                   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAABHCAYAAABfyaNkAAAACXBIWXMAAC4jAAAuIwF4pT92AAAIrklEQVR4Xu2dXXKzNhRAr5Am6Vu7kC6wS+qyuoxkYlAfhKQrIRn8R4x9zsw3HyFA/HbmimMwf/77nxcAAIAD8M/ff8mwdhAAAMAzgbgAAOBQIC4AADgUiAsAAA4F4gIAgEOBuAAA4FAgLgAAOBSICwAADsUwGL5/DAAAx8F9mC8ZxckkViZvxItZOwcAAODXcJ/Dl4zeyiQ2/O+tjGJl8qwiAgDA85HF5a2MJshr9GECiwJjCgMAgGfBfQ7fxaQVtk9pO/6OpUQAAHgG3Kf5CpIySl4mT2CTH9IUFvdHiQEAAOyN+0j3uFyS1KSmrSQxNYUFwRF0AADA/rjP4WsWk5VJ3+NK21YmM8hSZHoqI+gAAIB9cH/ME9eY5NOTl5bVsLgvRtABAAB74D7Md5BNlFS6x3UqhaVjjSqdJ+gAAIC9yEuFlZjS5JXENMgoTpoRx7wdRRfOHYSgAwAA7s3ie1xJWNV2c6oSp6TWOpegAwAA7kspLi2ZJCzXkdpQLCVuDTricVl2BB0AALAd92m+lVgGNV1p6TglqaHM5Qk6AABgR9LE1V4aLCUVBOSysB4QdIxixbOUCAAAHdyH+cqiUSLScUbcDvI5NSannpg2Bh16v8/bBB0AAFDjPm2oCrM0hrA02BBLPWndFnRYGWVoCpKgAwAAerg/zFfjvtapmKLGWWRJcLK8X1UKqx10hON+rg46wmcahKADAOB9adzjctXEY2U0P0Fas5TK47cEHUE4SUp6uuoEHVpk5bIkQQcAwDuTxVXLK92LUst5lZTaE1UpqTB5XRB06GtdEHQwhQEAvAfhtSZpea+anpJkXCkpOVVBh5PRD824Y0vQUUqqfOLGWtChP+s07yfoAAB4XdzH8D3fN9JiyRNSa8opxOStpKBDya4XdLSmq+XU1g464nXTO8L0kmMxnRF0AAC8Km4I2hJvRvHGKOkoeanpqrU0GH7uBx15/1At++lrnQ869DLm1qAjT2EEHQAAr4KLG2E28TKYSbw5heXANMHYthyUTO4ZdOhlv7E1XZ0JOsK5pSAJOgAAXgcnDYx4cXISMSeZzCyBxnLgQl7qXlRazutIqZyo4jk/+ecLgo4gsvLtzeVkR9ABAPAqNMWlGWSSwUxixchkTpV04vKeytaTZLYEHTYv9S2WFQk6AABgyaq4IkZ8WGwzo1gT7hlNWg6PDjq0jJpTG0EHAMA7sFlcmjiFedkQdGgB6WnHW1kLOuJyXrnsp69F0AEA8G5cJa7I5qBDSrFEmbSDDrcQUdjeFnQEMc3H67+7GnTMslMSJegAAHg+bhKXJgcdo0zGSG85cCEvLRyxMs6BRk9KhbzESgg1YkCilgfVkmM4vxV0BMERdAAAHIe7iSvjZZinsF7QkQXyI1PavxRZL+gIx5QT1dagI55D0AEAcEweIK7MMuiwMs3f77ou6GhMXkos7aAjPspq/l+fuxJ0jFFwesmxmM4IOgAA9uah4tLkoMNsCjqSpPS0UwvLW2kHHVYWS4Dp3JWgQ1w15cXtLUEHUxgAwKPZTVyRhwUdleyivFri6907C9f8KaS0FnSM/iT5afgEHQAAj2Z3cWli0BGfkxiksy3o0DKazI+S3XrQMXoly5aYkgR7QUcQU3FPzM/H66XH9JkIOgAA7sWviiuip7BzQUeUiX79ynKp8FzQYUW/fmVqSCb93Jn+WsuMefpT5xayCzIO3w1jCgMAuIWnEJemF3RkmWwPOqK8mpOXmq5aQUcW31AcvxRcK+iwUryAs9hP0AEAcAtPJy6NDjrcxqAjC6chrCScXtBh0/2qeuJrTVrhuBB0xN8RdAAAPJanFldkPehwsnhSRhLFswYd6pgwYwpBBwDAOocQl+ZeQcdo5ntl0pdSITuf77s1xZQkeGnQkbf1zwQdAABtDieuyHVBxzyZHSHoEDv/I+gAANAcVlyaVtCR3sCclhKDoIJIzgcd6f6TV2JR2+eCjvC7a4MOKykGKfYTdAAARF5CXBr94sutT+gYvZUpTWOVsJJwzgUdVtJzF5N0tgcd+hiCDgCA87ycuCLbgg4rRbaeRLEedATJxOOvCDrqJ27oCU5t6+MXshQrBB0A8G68rLg09w067Cy7OwQd6fx+0BH2t5YP1e99lhgAwKvzFuKKXBp0LCRTLBUSdAAA/AZvJS5NP+hwpbA6U04v6MjTUhlorAcdYWK6Luiwot/eHPYTdADAa/K24tKUQcePmnjOBx35FShVRZiEsxZ0qLc3Szi+NWllMRF0AAAgLsX2oEPJKsloe9ARjrks6AjHxSduhO+ibQ064t8g6ACAVwBxdWgHHUuZlKI4F3TUgqqlZKUOOsqpqv5760HHGGVVXL/8maADAI4G4lqhDDpOufBL0lkGHYWY6qXCYvJaBh16aa+WTPpZbS+DDhemOX3d3lKnVy++lEE8S4kAcAAQ1wWsBR2FKBrCaQcdOga5JuiwMsbpaiG4taDjJKN+Gj5BBwAcAMR1JbcEHWmq0ve5knC2Bh1uls4FQUcx8RF0AMAxQVw3skvQIUouerpK0tkSdGj5RXnl7XwuQQcAPDeI647UQUeUQy2TUhTtoCNKpjV5rQcdTvQXoGuprQYd+ngtuvQ5CDoA4PdAXA+gmMJ2DDqi7EqplfsX11fymqprNZc6ddDBFAYAvwDiejBbgo5zwlkPOrJw8uRUCasKOsIxtwYdsV4k6ACAfUFcO1IGHeqpGbsEHbWAbLpmIdBG0JH+trESX/1SnEvQAQA7grh+gTCbjDKYcUPQEWUSRXFZ0JEnsPr1LeeDjqX89LVsde6p+kxOwoN+WUoEgPuDuH6ZXtChp6KlKO4fdMSsvpfJrwUd8ZjF0mP6HAQdAHAfENeTcFvQEb7TVQirmLbaQUcUS7FsWNzvytv9oMPKuPislqADAB4G4npCNgcdHeGcCzrKKUpNS7WwGkFH2B4ax28JOtT++TiCDgC4hv8BmqUkeAWNmJAAAAAASUVORK5CYII="/>
                          </g>
                        </g>
                      </g>
                    </g>
                  </svg>
                </div>
              </div>
              <form class="mainstyle adbvdcfhr" novalidate @submit.prevent="autologin_user">
                <div class="mainstyle" style="margin-left: 30px;margin-right: 30px; text-align: left;">
                  <div v-if="positiveRegMessage" class="alert alert-success" role="alert">
                    Вы успешно зарегистрировались!
                  </div>
                  <div v-if="negativeRegMessage" class="alert alert-danger" role="alert">
                    Аккаунт такой уже есть!
                  </div>
                  <div class="mainstyle sdajhugty">Создайте учетную запись</div>
                  <div class="mainstyle dsfdscx">
                    <label class="mainstyle fdxads">
                      <div class="mainstyle dsdssa">
                        <div class="mainstyle fdsfcaqw">
                          <span class="sfasa">Фамилия</span>
                        </div>
                        <input autocapitalize="none"
                               id="suname"
                               v-model.trim="formReg.suname"
                               data-focusable="true"
                               dir="auto"
                               :class="status($v.formReg.suname)"
                               spellcheck="false"
                               autocomplete="off"
                               class="sdasd form-control"
                               name="session[suname]"
                               type="text"
                               @blur="$v.formReg.suname.$touch()">

                        <div v-if="!$v.formReg.suname.required" class="invalid-feedback">{{ reqText }}</div>
                        <div v-if="!$v.formReg.suname.alpha" class="invalid-feedback">{{ alphaText }}</div>
                      </div>
                    </label>
                  </div>
                  <div class="mainstyle dsfdscx">
                    <label class="mainstyle fdxads">
                      <div class="mainstyle dsdssa">
                        <div class="mainstyle fdsfcaqw">
                          <span class="sfasa">Имя</span>
                        </div>
                        <input autocapitalize="none"
                               id="name"
                               v-model.trim="formReg.name"
                               data-focusable="true"
                               dir="auto"
                               :class="status($v.formReg.name)"
                               spellcheck="false"
                               autocomplete="off"
                               class="sdasd form-control"
                               name="session[name]"
                               type="text"
                               @blur="$v.formReg.name.$touch()">

                        <div v-if="!$v.formReg.name.required" class="invalid-feedback">{{ reqText }}</div>
                        <div v-if="!$v.formReg.name.alpha" class="invalid-feedback">{{ alphaText }}</div>
                      </div>
                    </label>
                  </div>
                  <div class="mainstyle jytrvxa">
                    <div class="mainstyle eryczaq">
                      <select id="subdivision"
                              v-model="formReg.subdivision"
                              :class="status($v.formReg.subdivision)"
                              aria-label="Подразделения"
                              class="mainstyle hjrtndxr form-control"
                              @blur="$v.formReg.subdivision.$touch()">

                        <option aria-disabled="true" class="r-yfoy6g" disabled="" value="">Подразделения</option>
                        <option class="r-yfoy6g" value=1>4157</option>
                        <option class="r-yfoy6g" value=2>9070</option>
                        <option class="r-yfoy6g" value=3>8635</option>
                        <option class="r-yfoy6g" value=4>8636</option>
                        <option class="r-yfoy6g" value=5>8567</option>
                        <option class="r-yfoy6g" value=6>8645</option>
                        <option class="r-yfoy6g" value=7>8557</option>
                        <option class="r-yfoy6g" value=8>8556</option>
                      </select>
                      <svg class="mainstyle fdbera" viewBox="0 0 24 24">
                        <g>
                          <path
                              d="M20.207 8.147c-.39-.39-1.023-.39-1.414 0L12 14.94 5.207 8.147c-.39-.39-1.023-.39-1.414 0-.39.39-.39 1.023 0 1.414l7.5 7.5c.195.196.45.294.707.294s.512-.098.707-.293l7.5-7.5c.39-.39.39-1.022 0-1.413z"></path>
                        </g>
                      </svg>
                      <div v-if="!$v.formReg.subdivision.required" class="invalid-feedback">
                        {{ reqTextMin }}
                      </div>
                    </div>
                    <div class="mainstyle dsfdscx">
                      <label class="mainstyle fdxads">
                        <div class="mainstyle dsdssa">
                          <div class="mainstyle fdsfcaqw">
                            <span class="sfasa">ВСП</span>
                          </div>
                          <input autocapitalize="none"
                                 id="vsp"
                                 v-model.trim="formReg.vsp"
                                 data-focusable="true"
                                 dir="auto"
                                 :class="status($v.formReg.vsp)"
                                 spellcheck="false"
                                 autocomplete="off"
                                 class="sdasd form-control"
                                 name="session[vsp]"
                                 type="number"
                                 @blur="$v.formReg.vsp.$touch()">
                          <div v-if="!$v.formReg.vsp.required" class="invalid-feedback">{{ reqText }}</div>
                        </div>
                      </label>
                    </div>
                  </div>
                  <div class="mainstyle dsfdscx">
                    <label class="mainstyle fdxads">
                      <div class="mainstyle dsdssa">
                        <div class="mainstyle fdsfcaqw">
                          <span class="sfasa">Должность</span>
                        </div>
                        <input autocapitalize="none"
                               id="position"
                               v-model.trim="formReg.position"
                               data-focusable="true"
                               dir="auto"
                               :class="status($v.formReg.position)"
                               spellcheck="false"
                               autocomplete="off"
                               class="sdasd form-control"
                               name="session[position]"
                               type="text"
                               @blur="$v.formReg.position.$touch()">

                        <div v-if="!$v.formReg.position.required" class="invalid-feedback">{{ reqText }}</div>
                        <div v-if="!$v.formReg.position.alpha" class="invalid-feedback">{{ alphaText }}</div>
                      </div>
                    </label>
                  </div>
                  <input type="checkbox" style="margin-right: 15px;" id="checkbox">
                  <label for="checkbox">Запомнить меня</label>
                  <div class="mainstyle dsfdscx">
                    <button :disabled="regBtn" class="btn btn-primary rwerwsd" type="submit">
                      Зарегистрироваться
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {helpers, required} from 'vuelidate/lib/validators'
import axios from "axios";
// import {TOKEN} from "@/api/common";

// import axios from "axios";
// import {TOKEN} from "@/api/common";

const alpha = helpers.regex('alpha', /^[a-zA-Zа-яёА-ЯЁ]*$/)
export default {
  data() {
    return {
      negativeRegMessage: false,
      positiveRegMessage: false,
      reqText: 'Поле обязательно для заполнения',
      reqTextMin: 'обязательно',
      alphaText: 'Запрещены цифры, пробелы и другие символы',
      minLengthText: 'Минимальная длина 6 символов!',
      passwordConfirmText: 'Пароли не совпадают',
      formReg: {
        name: '',
        suname: '',
        subdivision: '',
        vsp: '',
        position: ''
      }
    }
  },
  computed: {
    regBtn() {
      return this.$v.formReg.name.$invalid ||
          this.$v.formReg.suname.$invalid
    },
  },
  methods: {
    status(validation) {
      return {
        'is-invalid': validation.$error,
        'error': validation.$error
      }
    },
    userRegister() {
      console.group("данные авторизации")
      console.log('Вы успешно зарегистрированны!')
      console.log('Ваше имя: ' + this.formReg.name)
      console.groupEnd()
    },
    showMessageRegistration(event) {
      if (event)
        this.positiveRegMessage = true;
      else
        this.negativeRegMessage = true;

      setTimeout(() => {
        this.negativeRegMessage = false
        this.positiveRegMessage = false
      }, 2500)
    },
    autologin_user() {
      axios.post('https://nesaweb.xyz/registration-authorization/signin/email', {
        method: 'registration',
        firstname: this.formReg.name,
        lastname: this.formReg.suname,
        division: 8635,
        position: this.formReg.position,
        email: "semyon3336@gmail.com"
      }).then(function (response) {
        console.log(response);
        this.$store.commit('updateToken', response.data.token)
        this.$store.commit("setAuthUser", {authUser: response.data, isAuthenticated: true})
        this.userRegister()
        this.showMessageRegistration(true)
        this.$router.push({name: 'home'})
      }).catch(function (error) {
        console.log(error);
        this.showMessageRegistration(false)
      });
    }
  },
  validations: {
    formReg: {
      name: {
        required,
        alpha
      },
      suname: {
        required,
        alpha
      },
      subdivision: {
        required
      },
      vsp: {
        required
      },
      position: {
        required,
        alpha
      }
    }
  }

}
</script>

<style scoped>

.dsaxz {
  height: 100%;
  display: flex;
  pointer-events: none !important;
  -ms-flex: 1 1 0%;
  -webkit-flex: 1;
  flex: 1;
  z-index: 1;
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
}

.sdacaae {
  position: fixed;
  right: 0;
  backface-visibility: hidden;
  left: 0;
  pointer-events: auto;
}

.scaweed {
  position: relative;
  bottom: 0;
  left: 0;
  right: 0;
  top: 0;
  display: block;
  min-width: 0;
  min-height: 0;
  -webkit-box-direction: normal;
  -webkit-box-orient: vertical;
  flex-direction: column;
  box-sizing: border-box;
  -webkit-box-align: stretch;
  align-items: stretch;
  z-index: 0;
  margin: 0;
  padding: 0;
  border-width: 0;
  border-style: solid;
}

.sadcae {
  -webkit-box-align: center;
  align-items: center;
  width: 100vw;
  -webkit-box-pack: center;
  justify-content: center;
  height: 100%;
  -webkit-box-direction: normal;
  -webkit-box-orient: horizontal;
  flex-direction: row;
  top: 0;
  position: fixed;
}

.dasdae {
  top: 0px;
  right: 0px;
  position: fixed;
  left: 0px;
  bottom: 0px;
  background-color: #21BA72;
}

.sdawcada {
  margin: auto;
  overflow: hidden;
  min-height: 400px;
  max-width: 80vw;
  max-height: 90vh;
  height: 70%;
  min-width: 600px;
  flex-shrink: 1;
  border-radius: 16px;

}

.styrtdacsd {
  -webkit-box-flex: 1;
  flex-grow: 1;
  flex-shrink: 1;
  background-color: #21BA72;
  align-self: stretch;
  display: flex;
}

.xcsseq {
  z-index: 2;
  height: 53px;
  padding-left: 15px;
  padding-right: 15px;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
  -webkit-box-direction: normal;
  -webkit-box-orient: horizontal;
  flex-direction: row;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
}

.sazjfg {
  -webkit-box-flex: 1;
  flex-grow: 1;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
  height: 100%;
  margin-top: 20px;
}

.adbvdcfhr {
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  -webkit-box-flex: 1;
  flex-grow: 1;
  max-width: 600px;
  flex-shrink: 1;
  overflow: auto;

}

.sdajhugty {
  font-size: 23px;
  overflow-wrap: break-word;
  line-height: 1.3125;
  color: rgb(255, 255, 255);
  margin-bottom: 15px;
  margin-top: 15px;
  min-width: 0px;
}

.dsfdscx {
  padding: 10px 0;
}

.fdxads {
  -webkit-box-direction: normal;
  -webkit-box-orient: horizontal;
  flex-direction: row;
  border-width: 1px;
  border-radius: 4px;
  border-color: rgb(255, 255, 255);
}

.dsdssa {
  -webkit-box-flex: 1;
  flex-grow: 1;
  flex-shrink: 1;
  padding: 2px 5px 5px;
  font-size: 19px;
}

.fdsfcaqw {
  -webkit-box-pack: justify;
  justify-content: space-between;
  -webkit-box-direction: normal;
  -webkit-box-orient: horizontal;
  flex-direction: row;
  text-align: left;
}

.sfasa {
  padding-top: 5px;
  /*font-weight: 400;*/
  font-size: 13px;
  overflow-wrap: break-word;
  min-width: 0;
  padding-left: 5px;
  padding-right: 5px;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.3125;
  color: #969696;
}

.sdasd {
  text-align: left;
  outline-style: none;
  font-size: inherit;
  font-family: inherit;
  color: inherit;
  resize: none;
  background-color: rgba(0, 0, 0, 0);
  box-sizing: border-box;
  width: 100%;
  padding: 0;
  border-width: 0;
  border-radius: 0;
  line-height: normal !important;
  height: auto;
}

.dfgsac {
  font-weight: 700;
  font-size: 15px;
}

.dfgsacd {
  font-weight: 400;
  font-size: 15px;
  color: #969696;
}

.jytrvxa {
  -webkit-box-direction: normal;
  -webkit-box-orient: horizontal;
  flex-direction: row;
  margin-bottom: 15px;
  margin-top: 15px;
}

.eryczaq {
  border-width: 1px;
  border-color: rgb(255, 255, 255);
  border-radius: 4px;
  background-color: rgb(160, 231, 32);
  -webkit-box-flex: 2;
  flex-grow: 2;
  margin-right: 10px;
}

.sdqqvcfs {
  -webkit-box-flex: 1;
  flex-grow: 1;
}

.gervsqe {
  pointer-events: none !important;
  padding-top: 5px;
  font-size: 13px;
  font-weight: 400;
  color: #969696;
  overflow-wrap: break-word;
  line-height: 1.3125;
  position: absolute;
  padding-left: 5px;
  padding-right: 5px;
}

.hjrtndxr {
  border-width: 0 !important;
  border-radius: 0 !important;
  color: rgb(255, 255, 255) !important;
  outline-style: none !important;
  font-size: 19px !important;
  appearance: none !important;
  cursor: pointer !important;
  margin: 5px 0 0 !important;
  padding: 10px 5px 5px !important;
  height: auto !important;
  line-height: normal !important;
  background-color: rgb(160, 231, 32) !important;
}

option {
  font-weight: normal;
  display: block;
  white-space: pre;
  min-height: 1.2em;
  padding: 0 2px 1px;
}

option:disabled {
  background-color: rgb(21, 32, 43);
  font-size: 19px;
  cursor: pointer;
}

.fdbera {
  display: inline-block;
  fill: currentcolor;
  max-width: 100%;
  vertical-align: text-bottom;
  -moz-user-select: none;
  -ms-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  position: absolute;
  color: rgb(136, 153, 166);
  pointer-events: none !important;
  height: 1.5em;
  margin-top: -0.75em;
  right: 10px;
  top: 50%;
}

.fsawec {
  background-color: #21BA72;
  flex-grow: 1;
  margin-right: 10px;
}

.rwerwsd {
  font-weight: 700;
  background-color: rgb(255 131 0);
  transition-property: background-color, box-shadow;
  transition-duration: 0.2s;
  min-height: 49px;
  border-radius: 9999px;
  border-style: solid;
  border-color: rgba(0, 0, 0, 0);
  border-width: 1px;
}
</style>