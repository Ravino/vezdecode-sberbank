import axios from "axios";

export const TOKEN = axios.create({
    baseURL: 'https://nesaweb.xyz'
})